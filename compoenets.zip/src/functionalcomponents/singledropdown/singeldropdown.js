import  React, {Component } from "react";
import DropdownTreeSelect from "react-dropdown-tree-select";
import 'react-dropdown-tree-select/dist/styles.css'

class Singledropdown extends DropdownTreeSelect {
  constructor(props) {
    super(props);
  }
}

Singledropdown.defaultProps = {
  simpleSelect: true,
  onChange : (currentNode, selectedNodes)=>{handle_Change(currentNode, selectedNodes)} ,
  onFocus : ()=> {},
  onBlur : ()=> {},
  className:"mdl-demo"
};

function handle_Change(currentNode, selectedNodes) {
    this.props.onChange(currentNode, selectedNodes)
}

export default  Singledropdown;
