import Tatvammultiselect from './tatvammultiselect';

export default Tatvammultiselect;
