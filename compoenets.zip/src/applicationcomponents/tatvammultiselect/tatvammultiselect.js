import Multidropdown from '../../functionalcomponents/multidropdown';
import React, { Component } from 'react';
let selected;
class Tatvammultiselect extends Multidropdown {
    constructor(props){
        super(props);
        this.state= {
            selected : []
        }
        this.handleChange=this.handleChange.bind(this);
        this.getValues=this.getValues.bind(this);
    }
    handleChange(currentNode, selectedNodes){
         selected = selectedNodes;
        // this.setState({selected })
        // console.log(selected)
    }
    getValues(){
        let values = selected;
        this.props.onBlur(values)
    }
    render(){
        return(
            <Multidropdown data={this.props.data} onChange={this.handleChange}  onBlur={this.getValues} />
            
        )
    }
} 
export default Tatvammultiselect;