import Tatvamsingleselect from './tatvamsingleselect';

export default Tatvamsingleselect;
