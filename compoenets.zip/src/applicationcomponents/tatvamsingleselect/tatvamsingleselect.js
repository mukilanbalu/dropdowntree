import Singledropdown from '../../functionalcomponents/singledropdown/';
import React, { Component } from 'react';

class Tatvamsingleselect extends Singledropdown {
    constructor(props){
        super(props);
    }
    render(){
        return(
            <Singledropdown data={this.props.data} onChange={this.props.onChange} />
            
        )
    }
} 
export default Tatvamsingleselect;