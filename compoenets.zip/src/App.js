import React, { Component } from "react";
import "./App.css";
import Tatvamsingleselect from "./applicationcomponents/tatvamsingleselect";
import Tatvammultiselect from "./applicationcomponents/tatvammultiselect";
const data = [
  {
  label: "Source",
  value: "Source",
  children: [
            {
              label: "Facebook",
              value: "Facebook"
            },
            {
              label: "Goodle",
              value: "Goodle"
            },
            {
              label: "Tripadvicer",
              value: "Tripadvicer"
            },
            {
              label: "Instagram",
              value: "Instagram"
            },
            {
              label: "Twitter",
              value: "Twitter"
            }
          ]
        }
]

class App extends Component {
  constructor(props){
    super(props);
    this.state = {
      main:''
    }
  }
  onChange(currentNode, selectedNodes) {
    this.setState({main : currentNode.value})
  }
  getvalues(value){
    this.setState({
      selected_Filter :{
        classsifier : this.state.main,
        values :value
      }
    })

  }
  render() {
    return (
      <div className="App">
        <Tatvamsingleselect data={data} onChange={this.onChange.bind(this)} />
        <Tatvammultiselect data={data[0].children} onBlur={this.getvalues.bind(this)} />
      </div>
    );
  }
}

export default App;
